import os
import sys

import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ml  # noqa: E402

SAMPLE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sample_data.csv")


@pytest.fixture(scope="module")
def result():
    return ml.analyze(pd.read_csv(SAMPLE), horizon=3)


def test_forecast_shape(result):
    assert [f["month"] for f in result["forecast"]] == ["2026-11", "2026-12", "2027-01"]
    assert all(f["lower"] <= f["kwh"] <= f["upper"] for f in result["forecast"])


def test_detects_injected_anomalies(result):
    months = {a["month"] for a in result["anomalies"]}
    assert {"2025-06", "2026-09"} <= months


def test_no_false_positives(result):
    assert {a["month"] for a in result["anomalies"]} == {"2025-06", "2026-09"}
    assert all(a["pct_above"] >= ml.MIN_PCT_ABOVE for a in result["anomalies"])


def test_backtest_accuracy(result):
    assert result["backtest"]["mape"] < 15


def test_summer_forecast_higher_than_winter():
    df = pd.read_csv(SAMPLE)
    r = ml.analyze(df, horizon=9)  # حتى يوليو 2027
    by_month = {f["month"]: f["kwh"] for f in r["forecast"]}
    assert by_month["2027-07"] > by_month["2026-12"]


def test_daily_data_is_aggregated():
    days = pd.date_range("2026-01-01", "2026-04-30", freq="D")
    df = pd.DataFrame({"date": days, "kwh": 10.0})
    monthly, _ = ml.to_monthly(df)
    assert len(monthly) == 4
    assert monthly.iloc[0] == pytest.approx(310.0)


def test_missing_months_are_filled():
    df = pd.DataFrame({"date": ["2026-01-01", "2026-03-01", "2026-04-01"], "kwh": [100, 120, 130]})
    monthly, missing = ml.to_monthly(df)
    assert missing == 1 and len(monthly) == 4


def test_too_little_data_raises():
    df = pd.DataFrame({"date": ["2026-01-01", "2026-02-01"], "kwh": [100, 110]})
    with pytest.raises(ValueError):
        ml.analyze(df)


def test_short_series_still_forecasts():
    df = pd.DataFrame({"date": pd.date_range("2026-01-01", periods=5, freq="MS"),
                       "kwh": [100, 105, 110, 108, 115]})
    r = ml.analyze(df, horizon=2)
    assert len(r["forecast"]) == 2 and r["model"]["harmonics"] == 0
